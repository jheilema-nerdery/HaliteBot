#!/bin/bash
ruby ./MyBot.rb
